$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CRMproject.feature");
formatter.feature({
  "line": 2,
  "name": "CRM Project",
  "description": "I want to use this template for my feature file",
  "id": "crm-project",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@crmactivity"
    }
  ]
});
formatter.scenario({
  "line": 6,
  "name": "counting dashlets",
  "description": "",
  "id": "crm-project;counting-dashlets",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@testcase1"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "User logged in to crm with \"admin\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "count the number of dashlets",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "print the number of title and dashlets",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "browse close",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 28
    },
    {
      "val": "pa$$w0rd",
      "offset": 40
    }
  ],
  "location": "crmProjectStep.user_logged_in_to_crm_with_and(String,String)"
});
formatter.result({
  "duration": 57612428000,
  "status": "passed"
});
formatter.match({
  "location": "crmProjectStep.count_the_number_of_dashlets()"
});
formatter.result({
  "duration": 3045707700,
  "status": "passed"
});
formatter.match({
  "location": "crmProjectStep.print_the_number_of_title_and_dashlets()"
});
formatter.result({
  "duration": 88800,
  "status": "passed"
});
formatter.match({
  "location": "crmProjectStep.browse_close()"
});
formatter.result({
  "duration": 4393089800,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Create lead",
  "description": "",
  "id": "crm-project;create-lead",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 12,
      "name": "@testcase2"
    }
  ]
});
formatter.step({
  "line": 14,
  "name": "user login to CRM with \"admin\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "user naviagte to create lead page",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Add details with \"test0102\" and \"testabcd12\"",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "verify details are added successfully",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "CLose the browser",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 24
    },
    {
      "val": "pa$$w0rd",
      "offset": 36
    }
  ],
  "location": "addleadStep.user_login_to_CRM_with_and(String,String)"
});
formatter.result({
  "duration": 59536906200,
  "status": "passed"
});
formatter.match({
  "location": "addleadStep.user_naviagte_to_create_lead_page()"
});
formatter.result({
  "duration": 1938109100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "test0102",
      "offset": 18
    },
    {
      "val": "testabcd12",
      "offset": 33
    }
  ],
  "location": "addleadStep.add_details_with_and(String,String)"
});
formatter.result({
  "duration": 6840411000,
  "status": "passed"
});
formatter.match({
  "location": "addleadStep.verify_details_are_added_successfully()"
});
formatter.result({
  "duration": 2416184300,
  "status": "passed"
});
formatter.match({
  "location": "addleadStep.browse_close()"
});
formatter.result({
  "duration": 4101524400,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 22,
  "name": "schedule meeting with 3 members",
  "description": "",
  "id": "crm-project;schedule-meeting-with-3-members",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@testcase3"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "User is on Login page with \"admin\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "meeting is scheduled",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "Members are added with \"\u003cFirstName\u003e\" \"\u003clastName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "verify meeting is created successfully",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "Close The browser",
  "keyword": "And "
});
formatter.examples({
  "line": 29,
  "name": "",
  "description": "",
  "id": "crm-project;schedule-meeting-with-3-members;",
  "rows": [
    {
      "cells": [
        "FirstName",
        "lastName"
      ],
      "line": 30,
      "id": "crm-project;schedule-meeting-with-3-members;;1"
    },
    {
      "cells": [
        "test",
        "testabcd"
      ],
      "line": 31,
      "id": "crm-project;schedule-meeting-with-3-members;;2"
    },
    {
      "cells": [
        "test",
        "test1"
      ],
      "line": 32,
      "id": "crm-project;schedule-meeting-with-3-members;;3"
    },
    {
      "cells": [
        "ananya",
        "sutradhar"
      ],
      "line": 33,
      "id": "crm-project;schedule-meeting-with-3-members;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 31,
  "name": "schedule meeting with 3 members",
  "description": "",
  "id": "crm-project;schedule-meeting-with-3-members;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@crmactivity"
    },
    {
      "line": 21,
      "name": "@testcase3"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "User is on Login page with \"admin\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "meeting is scheduled",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "Members are added with \"test\" \"testabcd\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "verify meeting is created successfully",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "Close The browser",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 28
    },
    {
      "val": "pa$$w0rd",
      "offset": 40
    }
  ],
  "location": "meetingscheduleStep.user_is_on_Login_page_with_and(String,String)"
});
formatter.result({
  "duration": 59470481700,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.meeting_is_scheduled()"
});
formatter.result({
  "duration": 2746339800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "test",
      "offset": 24
    },
    {
      "val": "testabcd",
      "offset": 31
    }
  ],
  "location": "meetingscheduleStep.members_are_added_with(String,String)"
});
formatter.result({
  "duration": 3461401000,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.verify_meeting_is_created_successfully()"
});
formatter.result({
  "duration": 131649200,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.close_The_browser()"
});
formatter.result({
  "duration": 165113500,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "schedule meeting with 3 members",
  "description": "",
  "id": "crm-project;schedule-meeting-with-3-members;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@crmactivity"
    },
    {
      "line": 21,
      "name": "@testcase3"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "User is on Login page with \"admin\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "meeting is scheduled",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "Members are added with \"test\" \"test1\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "verify meeting is created successfully",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "Close The browser",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 28
    },
    {
      "val": "pa$$w0rd",
      "offset": 40
    }
  ],
  "location": "meetingscheduleStep.user_is_on_Login_page_with_and(String,String)"
});
formatter.result({
  "duration": 58835025600,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.meeting_is_scheduled()"
});
formatter.result({
  "duration": 2820698400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "test",
      "offset": 24
    },
    {
      "val": "test1",
      "offset": 31
    }
  ],
  "location": "meetingscheduleStep.members_are_added_with(String,String)"
});
formatter.result({
  "duration": 3233174200,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.verify_meeting_is_created_successfully()"
});
formatter.result({
  "duration": 111136100,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.close_The_browser()"
});
formatter.result({
  "duration": 4117900600,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "schedule meeting with 3 members",
  "description": "",
  "id": "crm-project;schedule-meeting-with-3-members;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@crmactivity"
    },
    {
      "line": 21,
      "name": "@testcase3"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "User is on Login page with \"admin\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "meeting is scheduled",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "Members are added with \"ananya\" \"sutradhar\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "verify meeting is created successfully",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "Close The browser",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 28
    },
    {
      "val": "pa$$w0rd",
      "offset": 40
    }
  ],
  "location": "meetingscheduleStep.user_is_on_Login_page_with_and(String,String)"
});
formatter.result({
  "duration": 61563220000,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.meeting_is_scheduled()"
});
formatter.result({
  "duration": 2288418000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "ananya",
      "offset": 24
    },
    {
      "val": "sutradhar",
      "offset": 33
    }
  ],
  "location": "meetingscheduleStep.members_are_added_with(String,String)"
});
formatter.result({
  "duration": 3160867200,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.verify_meeting_is_created_successfully()"
});
formatter.result({
  "duration": 137377900,
  "status": "passed"
});
formatter.match({
  "location": "meetingscheduleStep.close_The_browser()"
});
formatter.result({
  "duration": 4129423600,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 37,
  "name": "creating product",
  "description": "",
  "id": "crm-project;creating-product",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 36,
      "name": "@testcase4"
    }
  ]
});
formatter.step({
  "line": 38,
  "name": "User is on CRM Login page with \"admin\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "product is added with \"\u003cname\u003e\" \"\u003cprice\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "verify product is created successfully with \"\u003cname\u003e\" \"\u003cprice\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "Close The BROWSER",
  "keyword": "And "
});
formatter.examples({
  "line": 43,
  "name": "",
  "description": "",
  "id": "crm-project;creating-product;",
  "rows": [
    {
      "cells": [
        "name",
        "price"
      ],
      "line": 44,
      "id": "crm-project;creating-product;;1"
    },
    {
      "cells": [
        "test123456",
        "$100.00"
      ],
      "line": 45,
      "id": "crm-project;creating-product;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 45,
  "name": "creating product",
  "description": "",
  "id": "crm-project;creating-product;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@crmactivity"
    },
    {
      "line": 36,
      "name": "@testcase4"
    }
  ]
});
formatter.step({
  "line": 38,
  "name": "User is on CRM Login page with \"admin\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "product is added with \"test123456\" \"$100.00\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "verify product is created successfully with \"test123456\" \"$100.00\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "Close The BROWSER",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 32
    },
    {
      "val": "pa$$w0rd",
      "offset": 44
    }
  ],
  "location": "addproductStep.user_is_on_CRM_Login_page_with_and(String,String)"
});
formatter.result({
  "duration": 63497962100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "test123456",
      "offset": 23
    },
    {
      "val": "$100.00",
      "offset": 36
    }
  ],
  "location": "addproductStep.product_is_added_with(String,String)"
});
formatter.result({
  "duration": 4697725000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "test123456",
      "offset": 45
    },
    {
      "val": "$100.00",
      "offset": 58
    }
  ],
  "location": "addproductStep.verify_product_is_created_successfully(String,String)"
});
formatter.result({
  "duration": 1755774200,
  "status": "passed"
});
formatter.match({
  "location": "addproductStep.close_The_BROWSER()"
});
formatter.result({
  "duration": 4351574200,
  "status": "passed"
});
});