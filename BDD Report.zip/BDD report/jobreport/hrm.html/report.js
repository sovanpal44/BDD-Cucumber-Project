$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("job.feature");
formatter.feature({
  "line": 2,
  "name": "Job Search",
  "description": "I want to use this template for my feature file",
  "id": "job-search",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@job"
    }
  ]
});
formatter.scenario({
  "line": 7,
  "name": "New User creation",
  "description": "",
  "id": "job-search;new-user-creation",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@jobtestcase1"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "User is logged on Alchemy Home Page with \"root\" and \"pa$$w0rd\"",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "All necessary details added",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "New user is created",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "CLOSE the browser",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "root",
      "offset": 42
    },
    {
      "val": "pa$$w0rd",
      "offset": 53
    }
  ],
  "location": "createUser.user_is_logged_on_Alchemy_Home_Page_with_and(String,String)"
});
formatter.result({
  "duration": 73045408900,
  "status": "passed"
});
formatter.match({
  "location": "createUser.all_necessary_details_added()"
});
formatter.result({
  "duration": 4656352000,
  "status": "passed"
});
formatter.match({
  "location": "createUser.new_user_is_created()"
});
formatter.result({
  "duration": 1155661400,
  "status": "passed"
});
formatter.match({
  "location": "createUser.close_the_browser()"
});
formatter.result({
  "duration": 4359017200,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Verify job post",
  "description": "",
  "id": "job-search;verify-job-post",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 22,
      "name": "@jobtestcase3"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "User is on Alchemy Job post page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "job details are submitted with \"test123400\" and \"test121\"",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "job is showing on job page",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "close the BROWSER",
  "keyword": "And "
});
formatter.match({
  "location": "jobpostStep.user_is_on_Alchemy_Job_post_page()"
});
formatter.result({
  "duration": 56521809800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "test123400",
      "offset": 32
    },
    {
      "val": "test121",
      "offset": 49
    }
  ],
  "location": "jobpostStep.job_details_are_submitted(String,String)"
});
formatter.result({
  "duration": 21862070100,
  "status": "passed"
});
formatter.match({
  "location": "jobpostStep.job_is_showing_on_job_page()"
});
formatter.result({
  "duration": 34664400,
  "status": "passed"
});
formatter.match({
  "location": "jobpostStep.close_the_BROWSER()"
});
formatter.result({
  "duration": 168662700,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 31,
  "name": "Verify job post with example",
  "description": "",
  "id": "job-search;verify-job-post-with-example",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 30,
      "name": "@jobtestcase4"
    }
  ]
});
formatter.step({
  "line": 32,
  "name": "User logged on Alchemy Job post page",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "job details are added with \"\u003cjobtitle\u003e\" and \"\u003cdescription\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "job is posted successfully",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "Close ThE browser",
  "keyword": "And "
});
formatter.examples({
  "line": 37,
  "name": "",
  "description": "",
  "id": "job-search;verify-job-post-with-example;",
  "rows": [
    {
      "cells": [
        "jobtitle",
        "description"
      ],
      "line": 38,
      "id": "job-search;verify-job-post-with-example;;1"
    },
    {
      "cells": [
        "test22",
        "abtestabcd"
      ],
      "line": 39,
      "id": "job-search;verify-job-post-with-example;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 39,
  "name": "Verify job post with example",
  "description": "",
  "id": "job-search;verify-job-post-with-example;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@job"
    },
    {
      "line": 30,
      "name": "@jobtestcase4"
    }
  ]
});
formatter.step({
  "line": 32,
  "name": "User logged on Alchemy Job post page",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "job details are added with \"test22\" and \"abtestabcd\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "job is posted successfully",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "Close ThE browser",
  "keyword": "And "
});
formatter.match({
  "location": "jobPostExample.user_logged_on_Alchemy_Job_post_page()"
});
formatter.result({
  "duration": 56368289500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "test22",
      "offset": 28
    },
    {
      "val": "abtestabcd",
      "offset": 41
    }
  ],
  "location": "jobPostExample.job_details_are_added_with_and(String,String)"
});
formatter.result({
  "duration": 21851254900,
  "status": "passed"
});
formatter.match({
  "location": "jobPostExample.job_is_posted_successfully()"
});
formatter.result({
  "duration": 31155300,
  "status": "passed"
});
formatter.match({
  "location": "jobPostExample.close_ThE_browser()"
});
formatter.result({
  "duration": 106790800,
  "status": "passed"
});
});