$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("job.feature");
formatter.feature({
  "line": 2,
  "name": "Job Search",
  "description": "I want to use this template for my feature file",
  "id": "job-search",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@job"
    }
  ]
});
formatter.scenario({
  "line": 15,
  "name": "Apply for job",
  "description": "",
  "id": "job-search;apply-for-job",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 14,
      "name": "@jobtestcase2"
    }
  ]
});
formatter.step({
  "line": 16,
  "name": "User is on Alchemy Job Page",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "Search for job",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "Apply for the job",
  "keyword": "Then "
});
formatter.step({
  "line": 19,
  "name": "close THE browser",
  "keyword": "And "
});
formatter.match({
  "location": "jobsearchStep.user_is_on_Alchemy_Job_Page()"
});
formatter.result({
  "duration": 58006788700,
  "status": "passed"
});
formatter.match({
  "location": "jobsearchStep.search_for_job()"
});
formatter.result({
  "duration": 6634486200,
  "status": "passed"
});
formatter.match({
  "location": "jobsearchStep.apply_for_the_job()"
});
formatter.result({
  "duration": 105496400,
  "status": "passed"
});
formatter.match({
  "location": "jobsearchStep.close_THE_browser()"
});
formatter.result({
  "duration": 81686700,
  "status": "passed"
});
});