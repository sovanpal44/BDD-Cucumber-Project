package Runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\SovanPal\\eclipse-workspace\\com.SDET.cucumber\\Features", glue = { "StepDefinitions" }, tags = { "@jobtestcase2" }, plugin = {
		"pretty", "json:target/cucumber-reports/Cucumber.json", "junit:target/cucumber-reports/Cucumber.xml",
		"html:target/cucumber-reports/hrm-report/hrm.html" }, monochrome = true, strict = true)

public class TestRunner {

}
