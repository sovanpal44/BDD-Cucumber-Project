package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class testSteps {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User is on Google Home Page$")
	public void openGoogle() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("https://www.google.com");
		driver.manage().window().maximize();

	}

	@When("^User types in Cheese and hits ENTER$")
	public void enterValue() {

		driver.findElement(By.xpath(".//*[@title='Search']")).sendKeys("Cheese", Keys.RETURN);

	}

	@Then("^Show how many search results were shown$")
	public void verifyResult() {

		String result = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("result-stats"))).getText();
		System.out.println("The number of result shown :" + result);

	}

	@And("^Close the browser$")
	public void closeBrowser() {

		driver.close();

	}

}
