package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class jobsearchStep {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User is on Alchemy Job Page$")
	public void user_is_on_Alchemy_Job_Page() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("https://alchemy.hguy.co/jobs?​");
		driver.manage().window().maximize();
		// driver.findElement(By.xpath(".//*[contains(text(),'Jobs')]")).click();

		driver.findElement(By.xpath(".//*[@id=\"menu-item-24\"]/a")).click();
	}

	@When("^Search for job$")
	public void search_for_job() throws Throwable {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.findElement(By.id("job_type_freelance")).click();
		driver.findElement(By.id("job_type_internship")).click();
		driver.findElement(By.id("job_type_part-time")).click();
		driver.findElement(By.id("job_type_temporary")).click();
		driver.findElement(By.id("search_keywords")).sendKeys("automation tester");
		driver.findElement(By.xpath(".//input[@type='submit']")).click();
//		driver.findElement(By.xpath(".//input[@id=\"search_keywords\"]")).sendKeys("automation tester", Keys.ENTER);
		Thread.sleep(5000);
		// driver.findElement(By.xpath(".//input[@type=\"submit\"]")).click();
		driver.findElement(By.xpath(".//*[@id='post-7']/div/div/ul/li[1]/a/div[1]/h3")).click();
		// driver.findElement(By.xpath(".//*[@id='post-7']/div/div/ul/li/a/div[1]/h3")).click();

	}

	@Then("^Apply for the job$")
	public void apply_for_the_job() throws Throwable {

		String title = driver.findElement(By.xpath(".//*[@id='post-1143']/div/header/div/h1")).getText();
		System.out.println("the title of the page :" + title);
		// driver.findElement(By.xpath(".//input[contains(text(),'Apply for job')]")).click();
		driver.findElement(By.xpath(".//*[@id='post-1143']/div/div/div/div[3]/input")).click();
	}

	@Then("^close THE browser$")
	public void close_THE_browser() throws Throwable {
		driver.close();
	}

}
