package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class createUser {
	WebDriver driver;
	WebDriverWait wait;

	@Given("^User is logged on Alchemy Home Page with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_is_logged_on_Alchemy_Home_Page_with_and(String username, String password) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("https://alchemy.hguy.co/jobs/wp-login.php?​");
		driver.manage().window().maximize();
		driver.findElement(By.name("log")).sendKeys(username);
		driver.findElement(By.name("pwd")).sendKeys(password);
		driver.findElement(By.xpath(".//*[@type='submit']")).click();

	}

	@When("^All necessary details added$")
	public void all_necessary_details_added() throws Throwable {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id=\"menu-users\"]/a/div[3]")).click();
		System.out.println("user is clicked");
		driver.findElement(By.xpath(".//*[@id=\"menu-users\"]/ul/li[3]/a")).click();
		driver.findElement(By.name("user_login")).sendKeys("a55sovanpal");
		driver.findElement(By.name("email")).sendKeys("111@test.com");
		driver.findElement(By.id("first_name")).sendKeys("Sovan");
		driver.findElement(By.id("last_name")).sendKeys("Pal");
		driver.findElement(By.xpath(".//*[@type='submit']")).click();

	}

	@Then("^New user is created$")
	public void new_user_is_created() throws Throwable {
		driver.findElement(By.xpath(".//*[@type='search']")).sendKeys("a5sovanpal", Keys.RETURN);
		// driver.findElement(By.xpath(".//*[@type='submit']")).click();
		String userName = driver.findElement(By.xpath(".//*[contains(text(),'Sovan Pal')]")).getText();
		Assert.assertEquals("Sovan Pal", userName);

	}

	@Then("^CLOSE the browser$")
	public void close_the_browser() throws Throwable {
		driver.close();
	}

}
