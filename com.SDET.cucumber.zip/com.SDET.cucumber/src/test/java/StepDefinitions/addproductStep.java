package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class addproductStep {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User is on CRM Login page with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_is_on_CRM_Login_page_with_and(String username, String password) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("https://alchemy.hguy.co/crm/");
		driver.manage().window().maximize();
		driver.findElement(By.id("user_name")).sendKeys(username);
		driver.findElement(By.id("username_password")).sendKeys(password);
		driver.findElement(By.id("bigbutton")).click();
	}

	@When("^product is added with \"([^\"]*)\" \"([^\"]*)\"$")
	public void product_is_added_with(String name, String price) throws Throwable {

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		Actions mousehover = new Actions(driver);
		mousehover.moveToElement(driver.findElement(By.xpath(".//*[@id=\"toolbar\"]/ul/li[7]"))).build().perform();
		driver.findElement(By.xpath(".//*[@id=\"toolbar\"]/ul/li[7]/span[2]/ul/li[25]/a")).click();
		driver.findElement(By.xpath(".//*[@id=\"actionMenuSidebar\"]/ul/li[1]/a/div[2]")).click();
		driver.findElement(By.xpath(".//*[@id=\"name\"]")).sendKeys(name);
		driver.findElement(By.xpath(".//*[@id=\"price\"]")).sendKeys(price);
		driver.findElement(By.xpath(".//*[@id=\"SAVE\"]")).click();

	}

	@Then("^verify product is created successfully with \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_product_is_created_successfully(String name, String price) throws Throwable {

		driver.findElement(By.xpath(".//*[@id=\"actionMenuSidebar\"]/ul/li[2]/a/div[2]")).click();
		String productName = driver.findElement(By.xpath("//*[@id=\"MassUpdate\"]/div[3]/table/tbody/tr[1]/td[3]")).getText();
		Assert.assertEquals(name, productName);
		String pricevalue = driver.findElement(By.xpath("//*[@id=\"MassUpdate\"]/div[3]/table/tbody/tr[1]/td[6]")).getText();
		Assert.assertEquals(price, pricevalue);
	}

	@Then("^Close The BROWSER$")
	public void close_The_BROWSER() throws Throwable {
		driver.close();
	}

}
