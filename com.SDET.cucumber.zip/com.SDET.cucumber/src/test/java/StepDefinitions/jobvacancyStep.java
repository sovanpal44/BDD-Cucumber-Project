package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class jobvacancyStep {

	WebDriverWait wait;
	WebDriver driver;

	@Given("^User logged in with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_logged_in_with_and(String username, String password) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.findElement(By.id("txtUsername")).sendKeys(username);
		driver.findElement(By.id("txtPassword")).sendKeys(password);
		driver.findElement(By.id("btnLogin")).click();
	}

	@When("^job vacancy is created$")
	public void job_vacancy_is_created() throws Throwable {

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id=\"menu_recruitment_viewRecruitmentModule\"]/b")).click();
		driver.findElement(By.xpath(".//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();
		driver.findElement(By.name("btnAdd")).click();
		Select dropdown = new Select(driver.findElement(By.xpath(".//*[@id=\"addJobVacancy_jobTitle\"]")));
		dropdown.selectByVisibleText("DevOps Engineer");
		driver.findElement(By.xpath(".//*[@id=\"addJobVacancy_name\"]")).sendKeys("test00228sovan");
		driver.findElement(By.xpath(".//*[@id=\"addJobVacancy_hiringManager\"]")).sendKeys("Test6 Test6");
		driver.findElement(By.xpath(".//*[@id=\"btnSave\"]")).click();
		driver.findElement(By.xpath(".//*[@id=\"btnBack\"]")).click();

	}

	@Then("^Verify vacancy is created$")
	public void verify_vacancy_is_created() throws Throwable {

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		// driver.findElement(By.xpath(".//*[@id=\"menu_recruitment_viewCandidates\"]")).click();
		// driver.findElement(By.xpath(".//a[@id=\"menu_recruitment_viewJobVacancy\"]")).click();
		// driver.findElement(By.xpath(".//*[contains(text(),'Vacancies']")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
		Select vacancy = new Select(driver.findElement(By.xpath(".//*[@id=\"vacancySearch_jobVacancy\"]")));

		vacancy.selectByVisibleText("test00228sovan");

	}

	@Then("^close browser$")
	public void close_browser() throws Throwable {

		driver.close();
	}

}
