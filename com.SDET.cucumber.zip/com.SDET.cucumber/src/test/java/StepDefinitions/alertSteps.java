package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class alertSteps {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User is on the page$")
	public void user_is_on_the_page() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("https://www.training-support.net/selenium/javascript-alerts");
		driver.manage().window().maximize();

	}

	@When("^User clicks the Simple Alert button$")
	public void user_clicks_the_Simple_Alert_button() throws Throwable {

		driver.findElement(By.id("simple")).click();

	}

	@When("^User clicks the Confirm Alert button$")
	public void user_clicks_the_Confirm_Alert_button() throws Throwable {

		driver.findElement(By.id("confirm")).click();

	}

	@When("^User clicks the Prompt Alert button$")
	public void user_clicks_the_Prompt_Alert_button() throws Throwable {

		driver.findElement(By.id("prompt")).click();

	}

	@Then("^Alert opens$")
	public void alert_opens() throws Throwable {

		driver.switchTo().alert();

	}

	@Then("^Read the text from it and print it$")
	public void read_the_text_from_it_and_print_it() throws Throwable {

		String alertMessage = driver.switchTo().alert().getText();
		System.out.println("Alert Message is :" + alertMessage);

	}

	@Then("^Close the alert$")
	public void close_the_alert() throws Throwable {

		driver.switchTo().alert().accept();

	}

	@Then("^Read the result text$")
	public void read_the_result_text() throws Throwable {

		driver.switchTo().alert().getText();
	}

	@Then("^Close Browser$")
	public void close_Browser() throws Throwable {

		driver.close();

	}

	@Then("^Write a custom message in it$")
	public void write_a_custom_message_in_it() throws Throwable {

		driver.switchTo().alert().sendKeys("Test");
		// driver.switchTo().alert().accept();
	}

	@And("^Close the alert with Cancel$")

	public void closeAlertWithCAncel() {

		driver.switchTo().alert().dismiss();

	}

}
