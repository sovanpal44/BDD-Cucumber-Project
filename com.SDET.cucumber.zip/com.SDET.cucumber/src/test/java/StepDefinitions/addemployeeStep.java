package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class addemployeeStep {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User logged in to the portal$")
	public void user_logged_in_to_the_portal() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.id("btnLogin")).click();
	}

	@When("^Add employee details \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void add_employee_details_and_and(String firstname, String lastname, String username, String userid) throws Throwable {

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id=\"menu_pim_viewPimModule\"]")).click();
		WebElement addBtn = driver.findElement(By.xpath(".//*[@id=\"btnAdd\"]"));
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id=\"btnAdd\"]")));
		addBtn.click();
		driver.findElement(By.xpath(".//*[@id=\"chkLogin\"]")).click();
		driver.findElement(By.xpath(".//*[@id=\"firstName\"]")).sendKeys(firstname);
		driver.findElement(By.xpath(".//*[@id=\"lastName\"]")).sendKeys(lastname);
		driver.findElement(By.xpath(".//*[@id=\"user_name\"]")).sendKeys(lastname);
		driver.findElement(By.xpath(".//*[@id=\"employeeId\"]")).clear();
		driver.findElement(By.xpath(".//*[@id=\"employeeId\"]")).sendKeys(userid);
		;
		driver.findElement(By.xpath(".//*[@id=\"btnSave\"]")).click();

	}

	@Then("^Verify employee details are added with \"([^\"]*)\"$")
	public void verify_employee_details_are_added(String userid) throws Throwable {

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id=\"menu_pim_viewPimModule\"]")).click();
		driver.findElement(By.xpath(".//*[@id=\"empsearch_id\"]")).sendKeys(userid);
		driver.findElement(By.xpath(".//*[@id=\"searchBtn\"]")).click();
		driver.findElement(By.xpath(".//*[@id=\"resultTable\"]/tbody/tr/td[1]")).click();

	}

	@Then("^browser close$")
	public void browser_close() throws Throwable {

		driver.close();
	}

}
