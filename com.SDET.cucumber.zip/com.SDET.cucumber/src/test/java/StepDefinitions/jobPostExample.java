package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class jobPostExample {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User logged on Alchemy Job post page$")
	public void user_logged_on_Alchemy_Job_post_page() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("https://alchemy.hguy.co/jobs?​");
		driver.manage().window().maximize();
		driver.findElement(By.xpath(".//*[contains(text(),'Post a Job')]")).click();

	}

	@When("^job details are added with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void job_details_are_added_with_and(String title, String desc) throws Throwable {

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id=\"submit-job-form\"]/fieldset[1]/div/a")).click();
		driver.findElement(By.name("log")).sendKeys("root");
		driver.findElement(By.name("pwd")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath(".//*[@type='submit']")).click();
		driver.findElement(By.xpath(".//*[@id=\"job_title\"]")).sendKeys(title);
		driver.switchTo().frame(0);
		WebElement description = driver.findElement(By.xpath(".//*[@id='tinymce']"));
		description.sendKeys(desc);
		driver.switchTo().defaultContent();
		driver.findElement(By.name("submit_job")).click();
		driver.findElement(By.xpath(".//*[@id='job_preview_submit_button']")).click();
	}

	@Then("^job is posted successfully$")
	public void job_is_posted_successfully() throws Throwable {

		String jobapplication = driver.findElement(By.xpath(".//*[@id='post-5']/div")).getText();
		if (jobapplication.equalsIgnoreCase("Job submitted successfully. Your listing will be visible once approved.")) {

			System.out.println("Job posted successfully");
		}

		else {
			System.out.println("Job not posted successfully");
		}

	}

	@Then("^Close ThE browser$")
	public void close_ThE_browser() throws Throwable {
		driver.close();
	}

}
