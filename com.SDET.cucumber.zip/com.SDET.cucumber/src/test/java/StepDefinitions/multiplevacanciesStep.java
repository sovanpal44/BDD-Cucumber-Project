package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class multiplevacanciesStep {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User is logged in to HRM with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_is_logged_in_to_HRM_with_and(String username, String password) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.findElement(By.id("txtUsername")).sendKeys(username);
		driver.findElement(By.id("txtPassword")).sendKeys(password);
		driver.findElement(By.id("btnLogin")).click();
	}

	@When("^Add vacancy details \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void add_vacancy_details_and_and(String jobtitle, String vacancyname, String hiringmanager) throws Throwable {

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id=\"menu_recruitment_viewRecruitmentModule\"]/b")).click();
		driver.findElement(By.xpath(".//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();
		driver.findElement(By.xpath(".//*[@id=\"btnAdd\"]")).click();
		System.out.println("button is clicked");
		Select dropdown = new Select(driver.findElement(By.xpath(".//*[@id=\"addJobVacancy_jobTitle\"]")));
		dropdown.selectByVisibleText(jobtitle);
		driver.findElement(By.xpath(".//*[@id=\"addJobVacancy_name\"]")).sendKeys(vacancyname);
		driver.findElement(By.xpath(".//*[@id=\"addJobVacancy_hiringManager\"]")).sendKeys(hiringmanager);
		driver.findElement(By.xpath(".//*[@id=\"btnSave\"]")).click();
		driver.findElement(By.xpath(".//*[@id=\"btnBack\"]")).click();

	}

	@Then("^Verify vacancy details are added with \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_vacancy_details_are_added_with_and_and(String jobtitle, String vacancyname, String hiringmanager) throws Throwable {

		// driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		// driver.findElement(By.xpath(".//*[@id=\"menu_recruitment_viewCandidates\"]")).click();
		// driver.findElement(By.xpath(".//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();
		Thread.sleep(10000);
		Select jobTitle = new Select(driver.findElement(By.xpath(".//*[@id=\"vacancySearch_jobTitle\"]")));
		System.out.println("dropdown clicked");
		jobTitle.selectByVisibleText(jobtitle);
		Thread.sleep(5000);
		Select vacancy = new Select(driver.findElement(By.id("vacancySearch_jobVacancy")));
		vacancy.selectByVisibleText(vacancyname);
		Select manager = new Select(driver.findElement(By.id("vacancySearch_hiringManager")));
		manager.selectByVisibleText(hiringmanager);

	}

	@Then("^browser now closed$")
	public void browser_now_closed() throws Throwable {
		driver.close();
	}

}
